#!/bin/bash

KEYS=(ok abort cancel yes no close save retry ignore help)
SOURCE="/home/ds/development/workspace/de.steinwedel.vaadin.addon.messagebox-project/messagebox/src/main/java/de/steinwedel/messagebox/i18n/captions/ButtonCaptions_"


for d in `find -maxdepth 1 -type d | sort | egrep "..+"`; do
	l=`echo $d | cut -c 3-`
	if [ -f "$SOURCE$l.java" ]; then
		echo "Ignore lang $l"
		continue
	fi

	if [ ! -f $l/messages/qt/kdeqt.po ]; then
		echo "No translations available for $l"
		continue
	fi

	ok=""
	abort=""
	cancel=""
	yes=""
	no=""
	close=""
	save=""
	retry=""
	ignore=""
	help=""

	for k in "${KEYS[@]}"; do
		v=`grep -m 1 -A 1 -iR "msgid \"$k\"" $l/messages/qt/kdeqt.po | egrep 'msgstr \".+\"' | cut -d '"' -f 2`
		if [ "$v" != "" ]; then
			eval "$k=\"$v\""
		else
			break
		fi	
	done

	if [ "$ok" != "" -a "$abort" != "" -a "$cancel" != "" -a "$yes" != "" -a "$no" != "" -a "$close" != "" -a "$save" != "" -a "$retry" != "" -a "$ignore" != "" -a "$help" != "" ]; then
		echo "Language '$l' is supported"
		(
			sed "s/--lang--/$l/g" before.txt
			echo -e "			{ButtonCaptionKey.OK.name(), \"$ok\"},"
			echo -e "			{ButtonCaptionKey.ABORT.name(), \"$abort\"},"
			echo -e "			{ButtonCaptionKey.CANCEL.name(), \"$cancel\"},"
			echo -e "			{ButtonCaptionKey.YES.name(), \"$yes\"},"
			echo -e "			{ButtonCaptionKey.NO.name(), \"$no\"},"
			echo -e "			{ButtonCaptionKey.CLOSE.name(), \"$close\"},"
			echo -e "			{ButtonCaptionKey.SAVE.name(), \"$save\"},"
			echo -e "			{ButtonCaptionKey.RETRY.name(), \"$retry\"},"
			echo -e "			{ButtonCaptionKey.IGNORE.name(), \"$ignore\"},"
			echo -e "			{ButtonCaptionKey.HELP.name(), \"$help\"},"
			cat after.txt
		) > "$SOURCE$l.java"
	else
		echo "Language '$l' is not supported"
	fi
done

